-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 21-07-2014 a las 02:59:14
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `rrhh`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `componentes`
-- 

CREATE TABLE `componentes` (
  `id_com` int(11) NOT NULL auto_increment,
  `url` varchar(100) collate utf8_spanish_ci NOT NULL,
  `archivo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campobd` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campoid` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campotitulo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campopalabras` varchar(100) collate utf8_spanish_ci NOT NULL,
  `campodescrip` varchar(100) collate utf8_spanish_ci NOT NULL,
  `rutaimagen` varchar(200) collate utf8_spanish_ci NOT NULL,
  `campoimagen` varchar(100) collate utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) collate utf8_spanish_ci NOT NULL,
  `descripcion` text collate utf8_spanish_ci NOT NULL,
  `menu_admin` varchar(255) collate utf8_spanish_ci NOT NULL,
  `html_admin` longtext collate utf8_spanish_ci NOT NULL,
  `email` varchar(255) collate utf8_spanish_ci NOT NULL default 'luisgago@lagc-peru.com',
  `fecha` varchar(11) collate utf8_spanish_ci NOT NULL,
  `visible` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id_com`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=10 ;

-- 
-- Volcar la base de datos para la tabla `componentes`
-- 

INSERT INTO `componentes` VALUES (1, 'usuarios', 'inicio', 'usuarios', 'id', 'usuarios', 'apellidos', 'apellidos', '', '', 'Personal', 'Configura las cuentas de usuarios que podran acceder a lagc.', 'Agregar>agregar|Importar>importar|Exportar>exportar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (2, 'inicio', 'index', '', '', '', '', '', '', '', 'Inicio', 'Inicio del Administrador', '', '', 'luisgago@lagc-peru.com', '1297124224', 1);
INSERT INTO `componentes` VALUES (3, 'sedes', 'inicio', '', '', '', '', '', '', '', 'Sedes', '̧ Sede o Lugar de trabajo', 'Agregar>agregar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (4, 'cursos', 'inicio', '', '', '', '', '', '', '', 'Cursos', 'Cursos', 'Crear>agregar|Asignar Curso>asignar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (5, 'examenes', 'inicio', '', '', '', '', '', '', '', 'Examenes Medicos', 'Creacion de Perfiles Medicos', 'Crear Exámen>agregar|Crear Clinica>agregarclinica|Asignar Perfil>asignar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (6, 'seguro', 'inicio', '', '', '', '', '', '', '', 'Seguro de Riesgo', '', 'Crear>agregar|Asignar Perfil>asignar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (7, 'asistencia', 'inicio', '', '', '', '', '', '', '', 'Asistencia', '', 'Exportar>exportar', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (8, 'reporte', 'inicio', '', '', '', '', '', '', '', 'Reportes', '', '', '', 'luisgago@lagc-peru.com', '1297122217', 1);
INSERT INTO `componentes` VALUES (9, 'configuracion', 'inicio', '', '', '', '', '', '', '', 'Config', 'Configuración de la APP', '', '', 'luisgago@lagc-peru.com', '1297122217', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_asistencia`
-- 

CREATE TABLE `com_asistencia` (
  `id_asis` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `apellidop` varchar(50) NOT NULL,
  `apellidom` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `dni` varchar(10) NOT NULL,
  `ensa` varchar(10) NOT NULL COMMENT 'Entrada/Salida',
  `sede` varchar(100) NOT NULL,
  `fecha` varchar(12) NOT NULL,
  PRIMARY KEY  (`id_asis`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `com_asistencia`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_cursos`
-- 

CREATE TABLE `com_cursos` (
  `curso_id` int(11) NOT NULL auto_increment,
  `curso_nombre` varchar(200) NOT NULL,
  `sede_id` varchar(100) NOT NULL COMMENT 'ID de sede',
  PRIMARY KEY  (`curso_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `com_cursos`
-- 

INSERT INTO `com_cursos` VALUES (1, 'Primer curso 1', '2');
INSERT INTO `com_cursos` VALUES (2, 'Segundo curso', '1');
INSERT INTO `com_cursos` VALUES (3, 'Cuarto curso1', '1');
INSERT INTO `com_cursos` VALUES (4, 'Quechua', '3');
INSERT INTO `com_cursos` VALUES (5, 'Mate', '4');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_curso_asignar`
-- 

CREATE TABLE `com_curso_asignar` (
  `id_asig_curso` int(11) NOT NULL auto_increment,
  `id_curso` int(11) NOT NULL COMMENT 'ID Curso',
  `id_usuario` int(11) NOT NULL,
  `fechainicio` varchar(12) NOT NULL,
  `fechafin` varchar(12) NOT NULL,
  `archivo` varchar(100) NOT NULL,
  `activo` int(1) NOT NULL COMMENT 'Activo/Desactivado',
  PRIMARY KEY  (`id_asig_curso`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- Volcar la base de datos para la tabla `com_curso_asignar`
-- 

INSERT INTO `com_curso_asignar` VALUES (1, 3, 2, '2014-06-03', '2014-06-04', '2_3_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_curso_asignar` VALUES (2, 4, 2, '2014-07-15', '', '', 1);
INSERT INTO `com_curso_asignar` VALUES (3, 1, 2, '2014-07-15', '2014-07-15', '', 0);
INSERT INTO `com_curso_asignar` VALUES (5, 2, 2, '2014-07-16', '2014-07-17', '2_2_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_curso_asignar` VALUES (12, 3, 1, '2014-07-05', '2014-07-06', '1_3_luisgagocasas.jpeg', 1);
INSERT INTO `com_curso_asignar` VALUES (11, 2, 1, '2014-07-19', '2014-07-12', '1_2_luisgagocasas.jpeg', 1);
INSERT INTO `com_curso_asignar` VALUES (10, 1, 1, '2014-07-04', '2014-07-05', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_examenes`
-- 

CREATE TABLE `com_examenes` (
  `examen_id` int(11) NOT NULL auto_increment,
  `examen_nombre` varchar(200) NOT NULL,
  `id_clinica` int(11) NOT NULL,
  `sede_id` varchar(100) NOT NULL COMMENT 'ID de sede',
  PRIMARY KEY  (`examen_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `com_examenes`
-- 

INSERT INTO `com_examenes` VALUES (1, 'Perfil 1', 1, '2');
INSERT INTO `com_examenes` VALUES (2, 'Perfil  2', 2, '1');
INSERT INTO `com_examenes` VALUES (3, 'Perfil 3', 3, '1');
INSERT INTO `com_examenes` VALUES (4, 'Perfil 3', 1, '3');
INSERT INTO `com_examenes` VALUES (5, 'Perfil 4', 2, '4');
INSERT INTO `com_examenes` VALUES (6, 'Perfil Aqui', 1, '1');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_examen_asignar`
-- 

CREATE TABLE `com_examen_asignar` (
  `id_asig_examen` int(11) NOT NULL auto_increment,
  `id_examen` int(11) NOT NULL COMMENT 'ID Curso',
  `id_usuario` int(11) NOT NULL,
  `fechainicio` varchar(12) NOT NULL,
  `fechafin` varchar(12) NOT NULL,
  `archivo` varchar(100) NOT NULL,
  `activo` int(1) NOT NULL COMMENT 'Activo/Desactivado',
  PRIMARY KEY  (`id_asig_examen`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- 
-- Volcar la base de datos para la tabla `com_examen_asignar`
-- 

INSERT INTO `com_examen_asignar` VALUES (1, 2, 2, '2014-07-10', '2014-07-11', '2_2_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_examen_asignar` VALUES (2, 3, 2, '', '', '2_3_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_examen_asignar` VALUES (3, 1, 2, '2014-07-01', '2014-07-02', '2_1_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_examen_asignar` VALUES (4, 1, 1, '2014-07-15', '2014-07-16', '', 1);
INSERT INTO `com_examen_asignar` VALUES (5, 2, 1, '2014-07-01', '2014-07-04', '', 1);
INSERT INTO `com_examen_asignar` VALUES (6, 3, 1, '2014-07-02', '2014-07-05', '', 1);
INSERT INTO `com_examen_asignar` VALUES (7, 6, 1, '2014-07-03', '2014-07-06', '', 1);
INSERT INTO `com_examen_asignar` VALUES (8, 2, 9, '2014-07-15', '', '', 1);
INSERT INTO `com_examen_asignar` VALUES (9, 3, 9, '2014-07-16', '', '', 0);
INSERT INTO `com_examen_asignar` VALUES (10, 6, 9, '2014-07-17', '', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_examen_clinica`
-- 

CREATE TABLE `com_examen_clinica` (
  `id_clinica` int(11) NOT NULL auto_increment,
  `nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `direccion` varchar(255) collate utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id_clinica`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `com_examen_clinica`
-- 

INSERT INTO `com_examen_clinica` VALUES (1, 'Primera clinica', 'direc. clinica', '3242343');
INSERT INTO `com_examen_clinica` VALUES (2, 'Segunda Clinica', 'direc. segunda clinica', '2353523');
INSERT INTO `com_examen_clinica` VALUES (3, 'Clinica Arequipa', 'dirección su Casa', '34233');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_sedes`
-- 

CREATE TABLE `com_sedes` (
  `sede_id` int(11) NOT NULL auto_increment,
  `sede_nombre` varchar(200) NOT NULL,
  `sede_ncontrato` varchar(100) NOT NULL,
  `sede_codigo` varchar(100) NOT NULL,
  `sede_estado` int(1) NOT NULL,
  PRIMARY KEY  (`sede_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `com_sedes`
-- 

INSERT INTO `com_sedes` VALUES (1, 'Arequipa', '23423', '4234', 1);
INSERT INTO `com_sedes` VALUES (2, 'Lima', '123', '456', 1);
INSERT INTO `com_sedes` VALUES (3, 'Cusco', '675', '8700', 1);
INSERT INTO `com_sedes` VALUES (4, 'Ica', '23423', '423423', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_seguros`
-- 

CREATE TABLE `com_seguros` (
  `seguro_id` int(11) NOT NULL auto_increment,
  `seguro_nombre` varchar(200) NOT NULL,
  `sede_id` varchar(100) NOT NULL COMMENT 'ID de sede',
  PRIMARY KEY  (`seguro_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `com_seguros`
-- 

INSERT INTO `com_seguros` VALUES (1, 'Clinica 1', '2');
INSERT INTO `com_seguros` VALUES (2, 'Clinica 2', '1');
INSERT INTO `com_seguros` VALUES (3, 'Clinica 3', '1');
INSERT INTO `com_seguros` VALUES (4, 'Clinica 3', '3');
INSERT INTO `com_seguros` VALUES (5, 'Clinica 4', '4');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `com_seguro_asignar`
-- 

CREATE TABLE `com_seguro_asignar` (
  `id_asig_seguro` int(11) NOT NULL auto_increment,
  `id_seguro` int(11) NOT NULL COMMENT 'IDseguro',
  `id_usuario` int(11) NOT NULL,
  `fechainicio` varchar(12) NOT NULL,
  `fechafin` varchar(12) NOT NULL,
  `archivo` varchar(100) NOT NULL,
  `activo` int(1) NOT NULL COMMENT 'Activo/Desactivado',
  PRIMARY KEY  (`id_asig_seguro`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `com_seguro_asignar`
-- 

INSERT INTO `com_seguro_asignar` VALUES (1, 2, 2, '2014-07-02', '2014-07-03', '', 1);
INSERT INTO `com_seguro_asignar` VALUES (2, 3, 2, '2014-07-03', '2014-07-04', '2_3_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_seguro_asignar` VALUES (3, 1, 2, '', '2014-07-11', '2_1_jose-luisapazacalisaya.jpeg', 1);
INSERT INTO `com_seguro_asignar` VALUES (4, 2, 1, '2014-07-04', '2014-07-05', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `configuracion`
-- 

CREATE TABLE `configuracion` (
  `nombreapp` varchar(100) collate utf8_spanish_ci NOT NULL,
  `correo` varchar(30) collate utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) collate utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) collate utf8_spanish_ci NOT NULL,
  `ruc` varchar(15) collate utf8_spanish_ci NOT NULL,
  `logo` varchar(20) collate utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `configuracion`
-- 

INSERT INTO `configuracion` VALUES ('RRHH', 'luisgago@lagc-peru.com', 'Mi Casa LL-14', '', '1234342342311', 'logo.png');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` tinyint(5) NOT NULL auto_increment,
  `usuario` varchar(50) collate utf8_spanish_ci NOT NULL,
  `password` varchar(32) collate utf8_spanish_ci NOT NULL COMMENT 'Encriptado con md5',
  `email` varchar(100) collate utf8_spanish_ci NOT NULL,
  `nombres` varchar(200) collate utf8_spanish_ci NOT NULL,
  `apellidop` varchar(200) collate utf8_spanish_ci NOT NULL,
  `apellidom` varchar(200) collate utf8_spanish_ci NOT NULL COMMENT 'Apellido Materno',
  `permisos` int(1) NOT NULL default '4' COMMENT 'Permisos de Usuarios | 1,2,3,4',
  `creadoel` varchar(11) collate utf8_spanish_ci NOT NULL COMMENT 'Cuando se creo',
  `ascreated` int(1) NOT NULL COMMENT 'Como se creo el registro 0>formulario 1>Importado',
  `modificadoel` varchar(11) collate utf8_spanish_ci NOT NULL COMMENT 'cuando se modifico',
  `imagen` varchar(100) collate utf8_spanish_ci NOT NULL COMMENT 'Imagen de Perfil',
  `dni` varchar(10) collate utf8_spanish_ci NOT NULL,
  `codigo` varchar(100) collate utf8_spanish_ci NOT NULL COMMENT 'Codigo Manual de la EMPRESA',
  `cargo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `fechanacimiento` varchar(10) collate utf8_spanish_ci NOT NULL,
  `departamento` int(5) NOT NULL,
  `celular` varchar(15) collate utf8_spanish_ci NOT NULL,
  `fechaingresoempresa` varchar(10) collate utf8_spanish_ci NOT NULL,
  `gsanguineo` varchar(10) collate utf8_spanish_ci NOT NULL COMMENT 'Grupo sanguíneo',
  `estado` int(1) NOT NULL COMMENT 'estado del personal',
  `genero` int(1) NOT NULL COMMENT 'sexo 1=hombre, 0=mujer',
  `comentario` text collate utf8_spanish_ci NOT NULL COMMENT 'Comentario del personal <> opcional',
  `sede_id` varchar(15) collate utf8_spanish_ci NOT NULL COMMENT 'ID''s de sedes',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=12 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 'luisgago', '938b4bc0ed0c9a281e9dc30273240fef', 'luisgago@maestro21.com', 'Luis', 'Gago', 'Casas', 1, '', 0, '1404280075', '1_luisgago-casas.png', '70332193', '', '', '1989-12-30', 4, '', '', '', 1, 1, '', '1|2|3');
INSERT INTO `usuarios` VALUES (2, 'admin', '93cbf3bc98f93c74031c78d6bf59236f', 'joseluis.ap.ca@gmail.com', 'José Luis', 'Apaza', 'Calisaya', 1, '', 0, '1403990674', '2_jose-luisapaza-calisaya.jpeg', '3534534', '', '', '', 4, '', '', '', 1, 1, 'aa', '1|2|3');
INSERT INTO `usuarios` VALUES (3, 'asistencia', '175a2cac015efe9993e2d25ea600a284', 'asistencia@asistencia.com', 'Asistencia', 'Asistencia', 'Asistencia', 3, '1404598215', 0, '1404598844', '', '32423432', '', '', '', 4, '', '', '', 1, 1, '', '');
INSERT INTO `usuarios` VALUES (4, '1234568', 'fe743d8d97aa7dfc6c93ccdc2e749513', 'edco@mail.com', 'Edco', 'Robles', 'Montero ', 4, '1405919878', 1, '', '', '70346521', '1234568', 'Operador', '10/05/1970', 0, '958345371', '06/05/2010', 'B+', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (5, '1234565', 'a071495b74b65a34559c76227e0633a4', 'generosa@mail.com', 'Generosa', 'Montez', 'Lemus', 4, '1405919878', 1, '', '', '70346522', '1234565', 'Operador', '11/05/1970', 0, '958345334', '07/05/2010', 'B-', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (6, '1234564', '9cf6f9edb58e7f3dadc1f65fdbe58b7a', 'alceo@mail.com', 'Alceo', 'Baca', 'Santillan', 4, '1405919878', 1, '', '', '70332173', '1234564', 'Operador', '12/05/1970', 0, '958345323', '08/05/2010', 'A+', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (7, '1234563', '11ea1cf4f9ed1fd9e94f451963c90365', 'neandro@mail.com', 'Neandro', 'Espinosa', 'Serrato', 4, '1405919878', 1, '', '', '70332194', '1234563', 'Operador', '13/05/1970', 0, '958345398', '09/05/2010', 'B+', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (8, '1234562', '6978915ee7dbc5aff1bc34b59e8c0fc5', 'isabelle@mail.com', 'Isabelle', 'Menendez', 'Diaz', 4, '1405919878', 1, '', '', '70346525', '1234562', 'Operador', '14/05/1970', 0, '958345322', '10/05/2010', 'B-', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (9, '1234561', 'e10adc3949ba59abbe56e057f20f883e', 'judas@mail.com', 'Judas', 'Giron', 'Mendoza', 4, '1405919878', 1, '1405920311', '', '70346526', '1234561', 'Operador', '', 1, '958345333', '', 'A+', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (10, '1234567', 'fcea920f7412b5da7be0cf42b8c93759', 'daisy@mail.com', 'Daisy', 'Prieto', 'Banda', 4, '1405919878', 1, '', '', '70346527', '1234567', 'Operador', '16/05/1970', 0, '958345351', '12/05/2010', 'A+', 0, 1, '', '');
INSERT INTO `usuarios` VALUES (11, '2345678', 'b3275960d68fda9d831facc0426c3bbc', 'ena@mail.com', 'Ena', 'Alva', 'Valencia', 4, '1405919878', 1, '', '', '70346528', '2345678', 'Operador', '17/05/1970', 0, '958345369', '13/05/2010', 'A-', 0, 1, '', '');
